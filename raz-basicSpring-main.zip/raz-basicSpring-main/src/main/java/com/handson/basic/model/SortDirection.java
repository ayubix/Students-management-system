package com.handson.basic.model;

public enum SortDirection {
    asc,desc
}
