package com.handson.basic.jwt;

import org.springframework.stereotype.Service;

@Service
public class UserService {


    public void save(DBUser user) {
    }
}
